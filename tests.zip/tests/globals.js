export const baseUrlForTest = 'http://localhost:8080/#/';
export const baseUrlForTestToBackend = 'http://liniya-back-p.dev-io.ru/api/';
